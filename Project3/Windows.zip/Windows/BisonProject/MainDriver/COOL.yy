%debug
%verbose
%locations

%code requires {
#include <iostream>
#include "ErrorMsg.h"
#include "StringTab.h"

void yyerror(char *s);	//called by the parser whenever an eror occurs
int yylex(void); /* function prototype */

}

%union {
	Symbol		symbol;	
	bool		boolean;	
}

%token <symbol>		STR_CONST TYPEID OBJECTID INT_CONST 
%token <boolean>	BOOL_CONST

%token CLASS IF ELSE FI LET IN 
%token INHERITS THEN WHILE LOOP POOL
%token CASE ESAC OF NOT NEW ISVOID 
%token ASSIGN LE DARROW

/* Precedence declarations. */
%left LET_STMT
%right ASSIGN
%left NOT
%left '-' '+'
%left '*' '/'

/*
* The above only gives precedence levels of some operators.
* Please provide precedence levels of other operators : LE '<' '=', ISVOID '~' '@' '.'
*/

%start program

%%

/*
 * The following is CFG of COOL programming languages. 
 * Several simple rules in the following comments are given for 
 * demonstration purpose.
 * You can uncomment them and provide extra rules for the CFG. 
 * Please be noted that you uncomment without providing extra rules, 
 * BISON will report errors when compiling COOL.yy file since 
 * several non-terminals are not defined by productions.
 * 
 
 * No rule action needed in this assignment 
 * If a recusive rule is needed, for example, define a list of something, always use 
 * right recursion like:
 * class_list : class class_list
 *
 */

 //This rule is introduced to avoid compilation error.
 //When you start working on the project, please delete this rule.
 program : /* empty body */
		;

 /*
//A COOL program is viewed as a list of classes 
program	: class_list
        ;

class_list 	: class			
        | error ';'             // error in the first class
		| class class_list 		// several classes
		| class_list error ';'  // error message 
		;

// If no parent is specified, the class inherits from the Object class. 
class : CLASS TYPEID '{' optional_feature_list '}' ';'
		| CLASS TYPEID INHERITS TYPEID '{' optional_feature_list '}' ';'
		;

// Feature list may be empty, but no empty features in list. 

optional_feature_list:		//empty body for this rule
        | feature_list
        ;
*/



/* end of grammar */

%%
#include <FlexLexer.h>
extern yyFlexLexer	lexer;

void yyerror(char *msg)
{	
	extern ErrorMsg errormsg;
	errormsg.error(yylloc.first_line, yylloc.first_column, msg);
}

int yylex(void)
{
	return lexer.yylex();
}


